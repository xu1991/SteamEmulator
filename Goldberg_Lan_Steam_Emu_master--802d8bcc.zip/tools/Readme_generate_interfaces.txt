Just drag your steam_api.dll or steam_api64.dll on the exe file and it will generate a steam_interfaces.txt file.

If it doesn't work, copy the steam_api dll beside the exe and then drag it on it or open up a command prompt and do: generate_interfaces_file.exe steam_api.dll
